public class ex18 {
    public static void main(String[] args) {
        int weight = 84;
        double height = 1.7;

        double bmi = weight / Math.pow(height, 2);
        System.out.println("BMI: " + bmi);
    }
}
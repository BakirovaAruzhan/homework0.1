public class ex3 {
    public static void main(String[] args) {
        int a = 8;
        int b = 12;
        int P = 2 * (a+b);
        int S = a * b;
        System.out.println(P);
        System.out.println(S);

    }
}
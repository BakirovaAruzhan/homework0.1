public class ex17{
    public static void main(String[] args) {

        String text = "Text";
        int length = text.length();
        System.out.println("Длина строки составляет: " + length);
    }

}

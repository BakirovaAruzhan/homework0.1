public class ex10{

    public static void main(String[] args) {

        String имя = "Аружан";
        String фамилия = "Бакирова";
        String полноеИмя = имя + " " + фамилия;
        System.out.println("Полное имя: " + полноеИмя);
    }
}

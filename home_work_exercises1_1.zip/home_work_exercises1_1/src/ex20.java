public class ex20 {
    public static void main(String[] args) {
        String numb1 = "25";
        String numb2 = "50";
        String concatenatedNumbers = numb1 + numb2;
        int firstnumber = Integer.parseInt(numb1);
        int secondnumber = Integer.parseInt(numb1);
        int sum = firstnumber + secondnumber;
        System.out.println("Сумма чисел " + numb1 + " и " + numb2 + " равна " + sum);



    }

}

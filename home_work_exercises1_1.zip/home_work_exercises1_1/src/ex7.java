
class ex7{

    public static void main(String[] args) {
        int a = 2;
        int b = 3;
        double geometricMean = Math.sqrt(a * b);
        System.out.println("Среднее геометрическое чисел " + a + " и " + b + " равно " + geometricMean);
    }
}
public class ex2 {
    public static void main(String[] args) {
        int age = 25;
        System.out.println(age);
    }
}


public class ex4 {
    public static void main(String[] args) {
        int f = 32;
        int fahrenheit = 50;
        int res = fahrenheit-f;
        double five = 5;
        double nine = 9;
        double result1 = five/nine;
        System.out.println(String.valueOf(result1));
        double s = 5/9;
        double res2= res*s;
        System.out.println(res2);
    }

}


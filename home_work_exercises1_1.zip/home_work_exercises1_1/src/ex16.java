public class ex16 {

    public static void main(String[] args) {
        int число = 5;
        int квадрат = число * число;
        int куб = число * число * число;
        System.out.println("Квадрат числа " + число + " равен " + квадрат);
        System.out.println("Куб числа " + число + " равен " + куб);
    }
}
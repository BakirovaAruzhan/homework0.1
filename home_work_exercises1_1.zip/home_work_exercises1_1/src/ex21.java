public class ex21 {

    public static void main(String[] args) {

        int years = 20;
        int days = years * 365;
        System.out.println("Количество дней в " + years + " годах равно " + days);
    }
}


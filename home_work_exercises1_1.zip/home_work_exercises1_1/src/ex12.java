import java.util.Scanner;
public class ex12 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int base = 10;
        int heigh = 5;
        double area = (base*heigh)/2;
        System.out.println("Площадь треугольника равна: "+ area);
    }


}

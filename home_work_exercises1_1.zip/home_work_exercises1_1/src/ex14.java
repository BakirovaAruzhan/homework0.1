public class ex14 {

    public static void main(String[] args) {
        int t = 360;
        int m = 60;
        int res = t / m;
        String res1 = res + " минут";

        System.out.println("В 360 часов: " + res1);
    }
}
public class ex22 {

    public static void main(String[] args) {

        int kzt = 1000;
      int skidka = 20;
      int res = kzt * skidka/100;
      int res2 = kzt -res;
        System.out.println("Конечная цена товара: " + res2);


    }

    }

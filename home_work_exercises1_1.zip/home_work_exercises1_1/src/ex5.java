public class ex5 {public static void main(String[] args) {
    int a = 5;
    int v = 3;
    int k = 4;
    int res1 = a + v + k;
    int res2 = res1 / 3;
    System.out.println(res2);
}
}

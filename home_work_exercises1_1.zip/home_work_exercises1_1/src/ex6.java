class ex6 {

    public static void main(String[] args) {
        int a = 2;
        int b = 3;
        int c = 4;
        int volume = a * b * c;
        int surfaceArea = 2 * (a * b + b * c + a * c);
        System.out.println("Объем параллелепипеда равен " + volume);
        System.out.println("Площадь поверхности параллелепипеда равна " + surfaceArea);
    }
}
public class ex11 {

    public static void main(String[] args) {
        int значение = 10;
        значение = значение ++;
        System.out.println("Значение переменной после увеличения на 10: "+ значение);

    }

}

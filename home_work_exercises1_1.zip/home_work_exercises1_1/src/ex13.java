public class ex13 {
    public static void main(String[] args) {
        int Aru = 1999;
        int Toty = 1991;
        int raz = Toty-Aru;
        System.out.println("Разница в возврасте:"+raz);
    }


    }

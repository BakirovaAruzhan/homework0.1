class ex9 {

    public static void main (String[]arg){

        int radius = 5;
        double pi =  3.14159;
        double area = pi * radius * radius;
        System.out.println(" Площадь круга с радиусовм "+ radius+" равна " + area );
    }

}

public class ex8 {

    public static void main(String[] args) {
        int счетчик = 10;

        int новоеЗначение = счетчик++;
        System.out.println("Значение переменной после увеличения на 1: " + новоеЗначение);

        новоеЗначение = счетчик--;
        System.out.println("Значение переменной после уменьшения на 2: " + новоеЗначение);
    }
}

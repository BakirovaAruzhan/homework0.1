public class ex15 {
    public static void main(String[] args) {
        String str1= "Аружан не знает метод, который использовала в этой задаче.";
        String str2= "Не факт, что запомнит, за то узнала.";
        String.join(str1, str2);
        String.join(str1, str2);
        System.out.println("str1: " + str1);
        System.out.println("str2: " + str2);
    }
}

public class ex2 {
    public static void main(String[] args) {
        int a = 74;
        int b = 36;
        int sum = a + b;
        System.out.println(sum);}

    }

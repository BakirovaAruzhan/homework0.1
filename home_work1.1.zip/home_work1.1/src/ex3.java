public class ex3 {
    public static void main(String[] args) {
        int a = 50;
        int b = 3;
        int div = a / b;

        System.out.println( div);}}
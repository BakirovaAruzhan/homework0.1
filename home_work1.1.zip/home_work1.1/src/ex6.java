public class ex6 {
    public static void main(String[] args) {
        int a = 125;
        int b = 24;
        int sum = a+b;
        int subs = a-b;
        int mul = a*b;
        int div = a/b;
        int mod = a%b;
        System.out.println("125 + 24 = "+ sum);
        System.out.println("125 - 24 = "+ subs);
        System.out.println("125 * 24 = "+ mul);
        System.out.println("125 / 24 = "+ div);
        System.out.println("125 % 24 = "+ mod);



    }
}


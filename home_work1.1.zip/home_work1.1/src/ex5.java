public class ex5 {
    public static void main(String[] args) {
        int a = 25;
        int b = 5;
        int div = a * b;

        System.out.println( div);
    }
}
